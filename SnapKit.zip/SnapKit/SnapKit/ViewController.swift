//
//  ViewController.swift
//  SnapKit
//
//  Created by Fatma Buyabes on 27/02/2024.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    
    let profileImageView = UIImageView()
    let codedLabel = UILabel()
    let usernameLabel = UILabel()
    let bioLabel = UILabel()
    let verificationImg = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        
        
        view.addSubview(profileImageView)
        profileImageView.image = UIImage(named: "CodedLogo")
        profileImageView.layer.cornerRadius = 37.5
        profileImageView.clipsToBounds = true
        
        view.addSubview(codedLabel)
        codedLabel.text = "CODED"
        codedLabel.font = UIFont.boldSystemFont(ofSize: 30)
        codedLabel.textColor = .white
        
        view.addSubview(usernameLabel)
        usernameLabel.text = "joincoded"
        usernameLabel.textColor = .white
        
        view.addSubview(bioLabel)
        bioLabel.text = "🥇 1st Coding Academy in Middle East\n🧑🏻‍💻 Learn To Code Websites, Apps, & MORE\n👩🏻‍🎓 Intensive Courses & Bootcamps\n🚀 1,500+ Graduates Since 2015"
        bioLabel.textColor = .white
        bioLabel.numberOfLines = 4 // Allow multiple lines
        bioLabel.lineBreakMode = .byWordWrapping
        
        view.addSubview(verificationImg)
        verificationImg.image = UIImage(named: "verify")
        profileImageView.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(0)
            make.trailing.equalToSuperview().offset(0)
            make.width.height.equalTo(75)
        }
        
       verificationImg.snp.makeConstraints { make in
           make.bottom.equalTo(profileImageView.snp.bottom).offset(3)
           make.leading.equalTo(profileImageView.snp.leading)
           make.width.height.equalTo(25)
        }
        
        codedLabel.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(0)
            make.left.equalTo(view.safeAreaLayoutGuide.snp.left).offset(10)
        }
        
        usernameLabel.snp.makeConstraints { make in
            make.bottom.equalTo(codedLabel).offset(30)
            make.left.equalTo(view.safeAreaLayoutGuide.snp.left).offset(10)
        }
        
        bioLabel.snp.makeConstraints { make in
            make.bottom.equalTo(usernameLabel).offset(120)
            make.left.equalTo(view.safeAreaLayoutGuide.snp.left).offset(5)
            
        }
        
    }
}

